#This file will used in bazel to build an application
print("Hello World")